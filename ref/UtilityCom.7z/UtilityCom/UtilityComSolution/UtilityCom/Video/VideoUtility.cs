﻿using AForge.Video.DirectShow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UtilityCom.Video
{
    public class VideoUtility
    {
        public static FilterInfoCollection GetDevices() 
        {
            try
            {
                FilterInfoCollection videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                return videoDevices;
            }
            catch (Exception ex)
            {
                Console.WriteLine("error:没有找到视频设备！具体原因：" + ex.Message);
                return null;
            }
        }
    }
}
