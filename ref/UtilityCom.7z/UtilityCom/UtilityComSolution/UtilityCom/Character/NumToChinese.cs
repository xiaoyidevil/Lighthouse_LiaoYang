﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace UtilityCom.Character
{
    /// <summary>
    /// 最大支持到千亿
    /// </summary>
    public class NumToChinese
    {
        private string[] arrNum = new string[] { "零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖" };
        private string[] arrUnit = new string[] { "", "拾", "佰", "仟" };
        private string[] arrBigUnit = new string[] { "", "万", "亿", "兆" };

        private Dictionary<string, string> ArrAudio = new Dictionary<string, string> { 
            { "零", "0" },
            { "壹", "1" },
            { "贰", "2" },
            { "叁", "3" },
            { "肆", "4" },
            { "伍", "5" },
            { "陆", "6" },
            { "柒", "7" },
            { "捌", "8" },
            { "玖", "9" },
            { "拾", "10" },
            { "佰", "bai" },
            { "仟", "qian" },
            { "万", "wan" },
            { "亿", "yi" },
            { "兆", "zhao" },
        };

        private string _numString;
        private double _dblNum;
        private float _fltNum;
        private decimal _intNum;

        //待转换的数字字符串
        public string NumString {
            get { return _numString; }
            set {
                _numString = value;

                if (float.MaxValue > double.MaxValue)
                {

                    float.Parse(value);
                }
                else
                {
                    double.Parse(value);
                }

                _intNum = int.Parse(value);
            }

        }

        public double DoubleNum { get { return _dblNum; } }
        public float FloatNum { get { return _fltNum; } }
        public decimal IntNum { get { return _intNum; } }

        public string ConvertToChinese() {
            string strResult = "";

            for (int i = 0; i < arrBigUnit.Length && _intNum>0; i++)
            {
                string tmp = "";
                for (int j = 0; j < arrUnit.Length && _intNum > 0; j++)
                {

                    if (Math.Truncate(_intNum % 10).ToString() == "0")
                    {
                        tmp = arrNum[int.Parse(Math.Truncate(_intNum % 10).ToString())] + tmp;
                    }
                    else {
                        tmp = arrNum[int.Parse(Math.Truncate(_intNum % 10).ToString())] + arrUnit[j] + tmp;
                    }
                    _intNum = Math.Floor(_intNum / 10);

                }
                strResult = tmp + arrBigUnit[i] + strResult;
            }

            return Regex.Replace(
                        Regex.Replace(strResult, "零+", "零"), "[零]$", "")
                .Replace("拾零", "拾")
                .Replace("壹拾", "拾");
        }

        public List<string> GetAudioList(string temp) {

            List<string> lstResult = new List<string>();

            foreach (char item in temp.ToArray())
            {
                lstResult.Add(ArrAudio[item.ToString()]);
            }

            return lstResult;
        }
    }
}
