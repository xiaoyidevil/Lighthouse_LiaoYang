﻿
namespace UtilityComForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPlayAudio = new System.Windows.Forms.Button();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtChineseNum = new System.Windows.Forms.TextBox();
            this.btnGetVideoDevice = new System.Windows.Forms.Button();
            this.videoSourcePlayer1 = new AForge.Controls.VideoSourcePlayer();
            this.cmbVideoList = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnStartCamera = new System.Windows.Forms.Button();
            this.btnCapture = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnStartRecord = new System.Windows.Forms.Button();
            this.btnPauseRecord = new System.Windows.Forms.Button();
            this.btnStopRecord = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPlayAudio
            // 
            this.btnPlayAudio.Location = new System.Drawing.Point(541, 45);
            this.btnPlayAudio.Name = "btnPlayAudio";
            this.btnPlayAudio.Size = new System.Drawing.Size(93, 23);
            this.btnPlayAudio.TabIndex = 0;
            this.btnPlayAudio.Text = "播放音频";
            this.btnPlayAudio.UseVisualStyleBackColor = true;
            this.btnPlayAudio.Click += new System.EventHandler(this.btnPlayAudio_Click);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(113, 24);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(422, 19);
            this.txtNum.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "播放内容";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "对应汉字";
            // 
            // txtChineseNum
            // 
            this.txtChineseNum.Location = new System.Drawing.Point(113, 48);
            this.txtChineseNum.Name = "txtChineseNum";
            this.txtChineseNum.Size = new System.Drawing.Size(422, 19);
            this.txtChineseNum.TabIndex = 3;
            // 
            // btnGetVideoDevice
            // 
            this.btnGetVideoDevice.Location = new System.Drawing.Point(305, 79);
            this.btnGetVideoDevice.Name = "btnGetVideoDevice";
            this.btnGetVideoDevice.Size = new System.Drawing.Size(93, 23);
            this.btnGetVideoDevice.TabIndex = 5;
            this.btnGetVideoDevice.Text = "获取摄像头";
            this.btnGetVideoDevice.UseVisualStyleBackColor = true;
            this.btnGetVideoDevice.Click += new System.EventHandler(this.btnGetVideoDevice_Click);
            // 
            // videoSourcePlayer1
            // 
            this.videoSourcePlayer1.Location = new System.Drawing.Point(113, 146);
            this.videoSourcePlayer1.Name = "videoSourcePlayer1";
            this.videoSourcePlayer1.Size = new System.Drawing.Size(320, 240);
            this.videoSourcePlayer1.TabIndex = 6;
            this.videoSourcePlayer1.Text = "videoSourcePlayer1";
            this.videoSourcePlayer1.VideoSource = null;
            // 
            // cmbVideoList
            // 
            this.cmbVideoList.FormattingEnabled = true;
            this.cmbVideoList.Location = new System.Drawing.Point(113, 82);
            this.cmbVideoList.Name = "cmbVideoList";
            this.cmbVideoList.Size = new System.Drawing.Size(186, 20);
            this.cmbVideoList.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "摄像头列表";
            // 
            // btnStartCamera
            // 
            this.btnStartCamera.Location = new System.Drawing.Point(404, 79);
            this.btnStartCamera.Name = "btnStartCamera";
            this.btnStartCamera.Size = new System.Drawing.Size(93, 23);
            this.btnStartCamera.TabIndex = 9;
            this.btnStartCamera.Text = "开启摄像头";
            this.btnStartCamera.UseVisualStyleBackColor = true;
            this.btnStartCamera.Click += new System.EventHandler(this.btnStartCamera_Click);
            // 
            // btnCapture
            // 
            this.btnCapture.Location = new System.Drawing.Point(503, 79);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(93, 23);
            this.btnCapture.TabIndex = 10;
            this.btnCapture.Text = "拍照";
            this.btnCapture.UseVisualStyleBackColor = true;
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(458, 146);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(320, 240);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // btnStartRecord
            // 
            this.btnStartRecord.Location = new System.Drawing.Point(113, 117);
            this.btnStartRecord.Name = "btnStartRecord";
            this.btnStartRecord.Size = new System.Drawing.Size(93, 23);
            this.btnStartRecord.TabIndex = 12;
            this.btnStartRecord.Text = "开始录像";
            this.btnStartRecord.UseVisualStyleBackColor = true;
            // 
            // btnPauseRecord
            // 
            this.btnPauseRecord.Location = new System.Drawing.Point(212, 117);
            this.btnPauseRecord.Name = "btnPauseRecord";
            this.btnPauseRecord.Size = new System.Drawing.Size(93, 23);
            this.btnPauseRecord.TabIndex = 12;
            this.btnPauseRecord.Text = "暂停录像";
            this.btnPauseRecord.UseVisualStyleBackColor = true;
            // 
            // btnStopRecord
            // 
            this.btnStopRecord.Location = new System.Drawing.Point(311, 117);
            this.btnStopRecord.Name = "btnStopRecord";
            this.btnStopRecord.Size = new System.Drawing.Size(93, 23);
            this.btnStopRecord.TabIndex = 12;
            this.btnStopRecord.Text = "停止录像";
            this.btnStopRecord.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 495);
            this.Controls.Add(this.btnStopRecord);
            this.Controls.Add(this.btnPauseRecord);
            this.Controls.Add(this.btnStartRecord);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCapture);
            this.Controls.Add(this.btnStartCamera);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbVideoList);
            this.Controls.Add(this.videoSourcePlayer1);
            this.Controls.Add(this.btnGetVideoDevice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtChineseNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.btnPlayAudio);
            this.Name = "Form1";
            this.Text = "通用类测试窗体";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPlayAudio;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtChineseNum;
        private System.Windows.Forms.Button btnGetVideoDevice;
        private AForge.Controls.VideoSourcePlayer videoSourcePlayer1;
        private System.Windows.Forms.ComboBox cmbVideoList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnStartCamera;
        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnStartRecord;
        private System.Windows.Forms.Button btnPauseRecord;
        private System.Windows.Forms.Button btnStopRecord;
    }
}

