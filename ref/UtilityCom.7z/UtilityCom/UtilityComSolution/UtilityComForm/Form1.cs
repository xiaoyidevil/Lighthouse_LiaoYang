﻿using AForge.Video.DirectShow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UtilityCom.Audio.MP3;
using UtilityCom.Character;
using UtilityCom.Video;

namespace UtilityComForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnPlayAudio_Click(object sender, EventArgs e)
        {
            NumToChinese numToChinese = new NumToChinese();

            numToChinese.NumString = txtNum.Text;
            txtChineseNum.Text = numToChinese.ConvertToChinese();

            List<string> arrAudioLst = numToChinese.GetAudioList(txtChineseNum.Text);

            foreach (string item in arrAudioLst)
            {
                clsMCI cm = new clsMCI();
                cm.FileName = AppDomain.CurrentDomain.BaseDirectory + @"Audio\" + item + ".mp3";
                cm.play();
                System.Threading.Thread.Sleep(300);
            }
        }

        private void btnGetVideoDevice_Click(object sender, EventArgs e)
        {
            FilterInfoCollection ficList = VideoUtility.GetDevices();
            if (ficList!= null && ficList.Count > 0) {
                cmbVideoList.Items.Clear();

                foreach (object item in ficList)
                {
                    cmbVideoList.Items.Add(item);
                }
            }
        }

        private void btnStartCamera_Click(object sender, EventArgs e)
        {
            FilterInfoCollection ficList = VideoUtility.GetDevices();
            videoSourcePlayer1.VideoSource = new VideoCaptureDevice(ficList[0].MonikerString);
            videoSourcePlayer1.Start();
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            Bitmap img = videoSourcePlayer1.GetCurrentVideoFrame();//拍摄
            pictureBox1.Image = img;
        }

        // 关闭并释放摄像头
        public void ShutCamera()
        {
            if (videoSourcePlayer1.VideoSource != null)
            {
                videoSourcePlayer1.SignalToStop();
                videoSourcePlayer1.WaitForStop();
                videoSourcePlayer1.VideoSource = null;
            }
        }

    }
}
