﻿using AForge.Video.DirectShow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UtilityCom.Audio.MP3;
using UtilityCom.Character;
using UtilityCom.Video;

namespace UtilityComForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnPlayAudio_Click(object sender, EventArgs e)
        {
            NumToChinese numToChinese = new NumToChinese();

            numToChinese.NumString = txtNum.Text;
            txtChineseNum.Text = numToChinese.ConvertToChinese();

            List<string> arrAudioLst = numToChinese.GetAudioList(txtChineseNum.Text);

            foreach (string item in arrAudioLst)
            {
                clsMCI cm = new clsMCI();
                cm.FileName = @"D:\workspace\JHHQ\material\Audio\" + item + ".mp3";
                cm.play();
                System.Threading.Thread.Sleep(300);
            }
        }

        private void btnGetVideoDevice_Click(object sender, EventArgs e)
        {
            FilterInfoCollection ficList = VideoUtility.GetDevices();
            if (ficList!= null && ficList.Count > 0) {
                cmbVideoList.Items.Clear();
                cmbVideoList.DataSource = ficList;
                //foreach (object item in ficList)
                //{
                //    cmbVideoList.Items.Add(item);
                //}
                cmbVideoList.DisplayMember = "Name";
                cmbVideoList.ValueMember = "MonikerString";
            }
        }

        private void btnStartCamera_Click(object sender, EventArgs e)
        {
            FilterInfoCollection ficList = VideoUtility.GetDevices();
            VideoCaptureDevice videoSource = new VideoCaptureDevice(ficList[0].MonikerString);
            videoSource.DesiredFrameSize = new Size(320, 240);
            videoSource.DesiredFrameRate = 1;
            videoSourcePlayer1.VideoSource = videoSource;
            
            videoSourcePlayer1.Start();
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            Bitmap img = videoSourcePlayer1.GetCurrentVideoFrame();//拍摄
            pictureBox1.Image = img;
            SavePicture();
        }

        // 关闭并释放摄像头
        public void ShutCamera()
        {
            if (videoSourcePlayer1.VideoSource != null)
            {
                videoSourcePlayer1.SignalToStop();
                videoSourcePlayer1.WaitForStop();
                videoSourcePlayer1.VideoSource = null;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            ShutCamera();
        }

        private void SavePicture()
        {
            try
            {
                TimeSpan tss = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
                long a = Convert.ToInt64(tss.TotalMilliseconds) / 1000;
                pictureBox1.Image.Save(string.Format("{0}.jpg", a.ToString()));
                
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
