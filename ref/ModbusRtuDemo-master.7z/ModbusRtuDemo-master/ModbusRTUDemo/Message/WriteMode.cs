﻿public enum WriteMode
{
    Write01 = 0x05,
    Write03 = 0x06,
    Write01s = 0x0F,
    Write03s = 0x10
}